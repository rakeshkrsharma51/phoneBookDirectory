import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  name = '';
  mobileNo = '';
  email = '';
  records = [];
  searchValue = '';

  addRecord() {
    const obj = {
      name: this.name,
      no: this.mobileNo,
      email: this.email
    };
    this.records.push(obj);
    this.name = '';
    this.mobileNo = '';
    this.email = '';
  }

  search() {
    // search code here
  }
}
